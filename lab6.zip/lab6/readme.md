```
Gel electrophoresis is an analysis method implemented in all disciplines of life sciences. The results of gel electrophoresis indicate the relative sizes of fragments, which is useful for restriction mapping and analyzing PCR fragments. 
```

This folder is dedicated to Bioinformatics Class lab6. 6 November 2025. 

```
Ugur Kaan 1242EA
Buga Mihai 1242EA
```


