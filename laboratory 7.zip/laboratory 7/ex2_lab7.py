from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt

Entrez.email = "bugamihai157@gmail.com"

def find_repetitions(seq, min_len=3, max_len=6, min_rep=2):
    out = {}
    for ln in range(min_len, max_len + 1):
        cnt = {}
        for i in range(len(seq) - ln + 1):
            p = seq[i:i + ln]
            if all(b in "ACGT" for b in p):
                cnt[p] = cnt.get(p, 0) + 1
        filt = {p: c for p, c in cnt.items() if c >= min_rep}
        if filt:
            out[ln] = dict(sorted(filt.items(), key=lambda x: (-x[1], x[0])))
    return out

def fetch_genome(acc):
    h = Entrez.efetch(db="nuccore", id=acc, rettype="fasta", retmode="text")
    rec = SeqIO.read(h, "fasta")
    h.close()
    return str(rec.seq).upper()

def main():
    accessions = [
        "NC_007373.1","NC_007366.1","NC_007368.1","NC_007371.1","NC_007367.1",
        "NC_002017.1","NC_002016.1","NC_002018.1","NC_002021.1","NC_002020.1"
    ]

    fig, axes = plt.subplots(5, 2, figsize=(14, 12))
    axes = axes.flatten()

    for ax, acc in zip(axes, accessions):
        try:
            print(f"Fetching genome {acc}...")
            seq = fetch_genome(acc)
            print(f"Analyzing genome of length {len(seq)} bases...")
            res = find_repetitions(seq, min_len=3, max_len=6, min_rep=2)
            labels, counts = [], []
            for ln in sorted(res.keys()):
                pats = res[ln]
                for pat, c in list(pats.items())[:5]:
                    labels.append(f"{pat} ({ln}bp)")
                    counts.append(c)
            ax.bar(labels, counts, color="#74b9ff", edgecolor="black")
            ax.set_title(acc, fontsize=10)
            ax.tick_params(axis="x", labelrotation=45, labelsize=8)
            ax.set_ylabel("Count", fontsize=8)
            ax.set_xlabel("Pattern", fontsize=8)
        except Exception as e:
            print(f"❌ Error processing {acc}: {e}")
            ax.text(0.5, 0.5, f"Error loading\n{acc}", ha="center", va="center")
            ax.axis("off")

    for ax in axes[len(accessions):]:
        ax.axis("off")

    plt.suptitle("Top Repetitive Patterns (3–6 bp) in 10 Influenza Genomes", fontsize=14, weight="bold")
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()

if __name__ == "__main__":
    main()
