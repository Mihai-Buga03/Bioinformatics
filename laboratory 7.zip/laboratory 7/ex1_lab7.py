def read_fasta(fname):
    seq = ""
    with open(fname, 'r') as f:
        for l in f:
            if not l.startswith('>'):
                seq += l.strip().upper()
    return seq

def find_repetitions(seq, min_len=3, max_len=6, min_rep=2):
    res = {}
    for ln in range(min_len, max_len + 1):
        pc = {}
        for i in range(len(seq) - ln + 1):
            pat = seq[i:i + ln]
            if all(b in 'ACGT' for b in pat):
                pc[pat] = pc.get(pat, 0) + 1
        rp = {p: c for p, c in pc.items() if c >= min_rep}
        if rp:
            res[ln] = dict(sorted(rp.items(), key=lambda x: (-x[1], x[0])))
    return res

def display_results(res, seq_len, top_n=10):
    print(f"DNA Sequence Analysis")
    print(f"Sequence length: {seq_len} nucleotides\n")
    print("=" * 70)
    for ln in sorted(res.keys()):
        pats = res[ln]
        print(f"\n{ln}-base pair patterns: {len(pats)} unique repetitive patterns found")
        print("-" * 70)
        cnt = 0
        for p, occ in pats.items():
            if cnt >= top_n:
                rem = len(pats) - top_n
                if rem > 0:
                    print(f"... and {rem} more patterns")
                break
            print(f"  {p}: {occ} occurrences")
            cnt += 1
    print("\n" + "=" * 70)
    print("Summary:")
    total = sum(len(pats) for pats in res.values())
    print(f"Total unique repetitive patterns found: {total}")
    max_c = 0
    max_p = ""
    for pats in res.values():
        for p, c in pats.items():
            if c > max_c:
                max_c = c
                max_p = p
    if max_p:
        print(f"Most frequent pattern: {max_p} ({max_c} occurrences)")

def main():
    fname = "seq.fasta"
    print(f"Reading sequence from {fname}...")
    try:
        seq = read_fasta(fname)
        if len(seq) < 1000:
            print(f"Warning: Sequence is only {len(seq)} bp (recommended: 1000-3000 bp)")
        elif len(seq) > 3000:
            print(f"Sequence is {len(seq)} bp. Analyzing first 3000 bp...")
            seq = seq[:3000]
        print(f"Analyzing {len(seq)} nucleotides...\n")
        res = find_repetitions(seq, min_len=3, max_len=6, min_rep=2)
        display_results(res, len(seq), top_n=10)
    except FileNotFoundError:
        print(f"Error: File '{fname}' not found!")
        print("Please ensure the FASTA file is in the same directory as this script.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
