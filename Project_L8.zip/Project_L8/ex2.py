import matplotlib.pyplot as plt
import numpy as np
import os
import random

def find_cleavage_sites(dna, pattern, offset):
    sites = []
    start = 0
    while True:
        index = dna.find(pattern, start)
        if index == -1:
            break
        sites.append(index + offset)
        start = index + 1
    return sorted(sites)

def digest_dna(dna, sites):
    if not sites:
        return [len(dna)]
    all_points = [0] + sites + [len(dna)]
    fragments = []
    for i in range(len(all_points) - 1):
        length = all_points[i+1] - all_points[i]
        if length > 0:
            fragments.append(length)
    return sorted(fragments, reverse=True)

def read_fasta_single(filename):
    if not os.path.exists(filename):
        return ''.join(random.choice('ATCG') for _ in range(5000))
    with open(filename, 'r') as f:
        seq = "".join(line.strip() for line in f if not line.startswith('>'))
    return ''.join(filter(str.isalpha, seq)).upper()

def read_fasta_multiple(filename):
    sequences = {}
    if not os.path.exists(filename):
        print(f"File {filename} not found. Generating 10 random variants...")
        for i in range(1, 11):
            base = ''.join(random.choice('ATCG') for _ in range(4000))
            var = ''.join(random.choice('ATCG') for _ in range(500))
            sequences[f"Var_{i}"] = base + var
        return sequences
        
    current_name = None
    current_seq = []
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            if line.startswith('>'):
                if current_name:
                    sequences[current_name] = ''.join(current_seq)
                current_name = line[1:].split()[0]
                current_seq = []
            else:
                current_seq.append(line)
        if current_name:
            sequences[current_name] = ''.join(current_seq)
    return sequences

enzymes = {
    "EcoRI":   {"seq": "GAATTC", "offset": 1},
    "BamHI":   {"seq": "GGATCC", "offset": 1},
    "HindIII": {"seq": "AAGCTT", "offset": 1},
    "TaqI":    {"seq": "TCGA",   "offset": 1},
    "HaeIII":  {"seq": "GGCC",   "offset": 2}
}

ladder_sizes = [10000, 8000, 6000, 5000, 4000, 3000, 2000, 1500, 1000, 500]
plt.style.use('dark_background')

print("--- Processing Part 1 (sequence-1.fasta) ---")
seq1 = read_fasta_single('sequence-1.fasta')
data_part1 = {}

print(f"Sequence 1 Length: {len(seq1)}")

for name, data in enzymes.items():
    cut_sites = find_cleavage_sites(seq1, data["seq"], data["offset"])
    fragments = digest_dna(seq1, cut_sites)
    data_part1[name] = fragments
    
    print(f"Enzyme: {name}")
    print(f"1. Cuts: {len(cut_sites)}")
    print(f"2. Pos: {cut_sites}")
    print(f"3. Lens: {fragments}")
    print("-" * 20)

data_part1["Marker"] = ladder_sizes

fig1, ax1 = plt.subplots(figsize=(8, 6))
names = list(data_part1.keys())
positions = np.arange(len(names))

ax1.set_yscale('log')
ax1.invert_yaxis()
ax1.set_ylim(20000, 50)

for i, name in enumerate(names):
    fragments = data_part1[name]
    ax1.add_patch(plt.Rectangle((i - 0.25, 20000), 0.5, 2000, color='#222222'))
    for size in fragments:
        if size < 50: continue
        ax1.hlines(size, i - 0.35, i + 0.35, colors='white', alpha=0.2, linewidth=6)
        ax1.hlines(size, i - 0.25, i + 0.25, colors='white', alpha=0.9, linewidth=2)
        if name == "Marker":
            ax1.text(i + 0.4, size, f"{size}", color='white', fontsize=7, va='center')

ax1.set_xticks(positions)
ax1.set_xticklabels(names, rotation=45, ha='right', color='white')
ax1.set_title("FIGURE 1: Sequence-1 Analysis", color='white')
ax1.grid(False)

print("\n--- Processing Part 2 (sequence-2.fasta) ---")
variants = read_fasta_multiple('sequence-2.fasta')
variant_names = list(variants.keys())[:10] 

rows, cols = 2, 5
fig2, axes = plt.subplots(rows, cols, figsize=(18, 10))
axes = axes.flatten()

for idx, ax in enumerate(axes):
    if idx < len(variant_names):
        name = variant_names[idx]
        dna = ''.join(filter(str.isalpha, variants[name])).upper()
        
        current_data = {}
        for enz_name, data in enzymes.items():
            cut_sites = find_cleavage_sites(dna, data["seq"], data["offset"])
            current_data[enz_name] = digest_dna(dna, cut_sites)
        current_data["Marker"] = ladder_sizes
        
        lane_names = list(current_data.keys())
        ax.set_yscale('log')
        ax.invert_yaxis()
        ax.set_ylim(20000, 50)
        
        for i, lane in enumerate(lane_names):
            frags = current_data[lane]
            ax.add_patch(plt.Rectangle((i - 0.25, 20000), 0.5, 2000, color='#222222'))
            for size in frags:
                if size < 50: continue
                ax.hlines(size, i - 0.35, i + 0.35, colors='white', alpha=0.2, linewidth=4)
                ax.hlines(size, i - 0.25, i + 0.25, colors='white', alpha=0.9, linewidth=1.5)
        
        ax.set_title(name, color='white', fontsize=9)
        ax.set_xticks([]) 
        ax.grid(False)
    else:
        ax.axis('off')
fig2.suptitle("FIGURE 2: Individual Variant Profiles", color='white', fontsize=16)

processed_variants = {}
for name in variant_names:
    dna = ''.join(filter(str.isalpha, variants[name])).upper()
    all_frags = []
    for data in enzymes.values():
        cut_sites = find_cleavage_sites(dna, data["seq"], data["offset"])
        all_frags.extend(digest_dna(dna, cut_sites))
    processed_variants[name] = sorted(all_frags, reverse=True)

fragment_sets = [set(frags) for frags in processed_variants.values()]
if fragment_sets:
    common_bands = set.intersection(*fragment_sets)
else:
    common_bands = set()

print(f"Differential Analysis: Removed {len(common_bands)} common bands.")

unique_data = {}
for name, frags in processed_variants.items():
    unique_data[name] = [f for f in frags if f not in common_bands]

unique_data["Marker"] = ladder_sizes

fig3, ax3 = plt.subplots(figsize=(12, 8))
diff_names = list(unique_data.keys())
diff_pos = np.arange(len(diff_names))

ax3.set_yscale('log')
ax3.invert_yaxis()
ax3.set_ylim(20000, 50)

for i, name in enumerate(diff_names):
    fragments = unique_data[name]
    ax3.add_patch(plt.Rectangle((i - 0.25, 20000), 0.5, 2000, color='#222222'))
    
    for size in fragments:
        if size < 50: continue
        col = 'cyan' if name != "Marker" else 'white'
        
        ax3.hlines(size, i - 0.35, i + 0.35, colors=col, alpha=0.2, linewidth=6)
        ax3.hlines(size, i - 0.25, i + 0.25, colors=col, alpha=0.9, linewidth=2)
        
        if name == "Marker":
            ax3.text(i + 0.4, size, f"{size}", color='white', fontsize=7, va='center')

ax3.set_xticks(diff_pos)
ax3.set_xticklabels(diff_names, rotation=45, ha='right', color='white')
ax3.set_title("FIGURE 3: Merged Differential Display (Common Bands Removed)", color='white', fontsize=14)
ax3.set_ylabel("Fragment Size (bp)", color='white')
ax3.grid(False)

plt.show()