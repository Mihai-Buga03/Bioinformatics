import matplotlib.pyplot as plt
import numpy as np
import os
import random

def find_cleavage_sites(dna, pattern, offset):
    sites = []
    start = 0
    while True:
        index = dna.find(pattern, start)
        if index == -1:
            break
        sites.append(index + offset)
        start = index + 1
    return sorted(sites)

def digest_dna(dna, sites, is_circular=False):
    if not sites:
        return [len(dna)]
    
    if is_circular:
        fragments = []
        fragments.append((len(dna) - sites[-1]) + sites[0])
        for i in range(len(sites) - 1):
            fragments.append(sites[i+1] - sites[i])
        return sorted(fragments, reverse=True)
    else:
        all_points = [0] + sites + [len(dna)]
        fragments = []
        for i in range(len(all_points) - 1):
            length = all_points[i+1] - all_points[i]
            if length > 0:
                fragments.append(length)
        return sorted(fragments, reverse=True)

def read_fasta_file(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    sequence = ""
    for line in lines:
        if not line.startswith('>'):
            sequence += line.strip()
    return sequence

def generate_random_dna(length=5000):
    return ''.join(random.choice('ATCG') for _ in range(length))

filename = 'sequence-2.fasta'

if os.path.exists(filename):
    print(f"Loading {filename}...")
    raw_sequence = read_fasta_file(filename)
    dna_sequence = ''.join(filter(str.isalpha, raw_sequence)).upper()
else:
    print(f"File {filename} not found. Generating random sequence for demonstration...")
    dna_sequence = generate_random_dna(8000)

if dna_sequence:
    enzymes = {
        "EcoRI": {"seq": "GAATTC", "offset": 1},
        "BamHI": {"seq": "GGATCC", "offset": 1},
        "HindIII": {"seq": "AAGCTT", "offset": 1},
        "TaqI":   {"seq": "TCGA",   "offset": 1},
        "HaeIII": {"seq": "GGCC",   "offset": 2}
    }

    digest_results = {}

    print(f"Sequence Length: {len(dna_sequence)} bp")
    print("-" * 30)

    for name, data in enzymes.items():
        cut_sites = find_cleavage_sites(dna_sequence, data["seq"], data["offset"])
        
        fragments = digest_dna(dna_sequence, cut_sites, is_circular=False)
        
        digest_results[name] = fragments
        
        print(f"Enzyme: {name}")
        print(f"Cuts: {len(cut_sites)} | Fragments: {fragments}")
        print("-" * 30)

    ladder_sizes = [10000, 8000, 6000, 5000, 4000, 3000, 2000, 1500, 1000, 500]
    digest_results["Marker"] = ladder_sizes

    plt.style.use('dark_background')
    
    fig, ax = plt.subplots(figsize=(6, 8))
    
    names = list(digest_results.keys())
    lane_positions = np.arange(len(names))
    
    ax.set_yscale('log')
    
    ax.invert_yaxis()
    
    ax.set_ylim(20000, 100)
    
    for i, name in enumerate(names):
        fragments = digest_results[name]
        
        ax.add_patch(plt.Rectangle((i - 0.25, 20000), 0.5, 2000, color='#222222'))
        
        for size in fragments:
            if size < 100: continue
            
            ax.hlines(size, i - 0.35, i + 0.35, colors='white', alpha=0.2, linewidth=6)
            ax.hlines(size, i - 0.25, i + 0.25, colors='white', alpha=0.9, linewidth=2)
            
            if name == "Marker":
                ax.text(i + 0.4, size, f"{size}", color='white', fontsize=7, va='center')

    ax.set_xticks(lane_positions)
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=10, color='white')
    ax.set_ylabel("Base Pairs (bp) - Log Scale", color='white')
    ax.set_title(f"Restriction Digest Simulation\n({len(dna_sequence)} bp)", color='white', pad=20)
    
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.spines['left'].set_visible(True)
    ax.spines['left'].set_color('white')

    plt.tight_layout()
    plt.show()