import matplotlib.pyplot as plt

def calculate_cg_content(sequence):
    c_count = sequence.count('C')
    g_count = sequence.count('G')
    return ((c_count + g_count) / len(sequence)) * 100

def calculate_ic(sequence):
    n = len(sequence)
    if n <= 1:
        return 0
    counts = {base: sequence.count(base) for base in ['A', 'C', 'G', 'T']}
    numerator = sum(count * (count - 1) for count in counts.values())
    denominator = n * (n - 1)
    return (numerator / denominator) * 100

def get_sliding_window_data(sequence, window_size):
    cg_values = []
    ic_values = []
    
    for i in range(len(sequence) - window_size + 1):
        window = sequence[i : i + window_size]
        cg_values.append(calculate_cg_content(window))
        ic_values.append(calculate_ic(window))
        
    return cg_values, ic_values

def calculate_center_of_weight(values):
    return sum(values) / len(values)

S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
WINDOW_SIZE = 30

cg_data, ic_data = get_sliding_window_data(S, WINDOW_SIZE)

cg_center = calculate_center_of_weight(cg_data)
ic_center = calculate_center_of_weight(ic_data)

print(f"Calculated Center of Weight (Average) CG%: {cg_center:.2f}")
print(f"Calculated Center of Weight (Average) IC: {ic_center:.2f}")

plt.figure(figsize=(10, 6))
plt.plot(cg_data, label='C+G %', color='blue')
plt.plot(ic_data, label='Kappa IC', color='red')
plt.title('DNA Pattern: C+G% and Kappa IC (Sliding Window)')
plt.xlabel('Window Position')
plt.ylabel('Value')
plt.legend()
plt.grid(True)
plt.show()

plt.figure(figsize=(6, 6))
plt.scatter(cg_center, ic_center, color='purple', s=100, label='Center of Weight')
plt.title('Center of Weight (Centroid)')
plt.xlabel('Average C+G %')
plt.ylabel('Average Kappa IC')
plt.legend()
plt.grid(True)
plt.show()