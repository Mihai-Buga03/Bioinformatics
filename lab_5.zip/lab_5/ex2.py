from Bio import Entrez, SeqIO
import random
import time
import matplotlib.pyplot as plt

Entrez.email = "bugamhai157@gmail.com"

accessions = [
    "NC_045512.2",  # SARS-CoV-2 ~30k bases
    "NC_001802.1",  # Influenza A virus ~13.5k
    "NC_002528.1",  # Human respiratory syncytial virus B (3rd)
    "NC_001434.1",  # Measles virus ~15.8k
    "NC_002645.1",  # Respiratory syncytial virus A ~15.2k
    "NC_003899.1",  # Mumps virus ~15.3k
    "NC_001710.1",  # Rabies virus ~11.9k
    "NC_002058.1",  # HIV-1 ~9.7k
    "NC_006213.1",  # Human parainfluenza virus 1 (replacement for 9th)
    "NC_001781.1"   # Human coronavirus OC43 ~30.7k


]

def get_genome_sequence(accession):
    try:
        handle = Entrez.efetch(db="nucleotide", id=accession, rettype="fasta", retmode="text")
        record = SeqIO.read(handle, "fasta")
        handle.close()
        return str(record.seq)
    except Exception as e:
        print(f"Error fetching accession {accession}: {e}")
        return None

def sample_sequence(seq, sample_count=1500, min_len=100, max_len=150):
    samples = []
    length_seq = len(seq)
    for _ in range(sample_count):
        length = random.randint(min_len, max_len)
        start = random.randint(0, length_seq - length)
        samples.append(seq[start:start+length])
    return samples

def get_overlap_len(s1, s2, min_overlap=10):
    max_len = min(len(s1), len(s2))
    for overlap_len in range(max_len, min_overlap - 1, -1):
        if s1[-overlap_len:] == s2[:overlap_len]:
            return overlap_len
    return 0

def assemble(samples):
    overlap_graph = {}
    for i, s1 in enumerate(samples):
        overlap_graph[i] = []
    for i, s1 in enumerate(samples):
        for j, s2 in enumerate(samples):
            if i != j:
                olen = get_overlap_len(s1, s2)
                if olen >= 10:
                    overlap_graph[i].append((j, olen))
    visited = set()
    assembly_path = []
    current = 0
    visited.add(current)
    assembly_path.append(current)
    while True:
        neighbors = overlap_graph.get(current, [])
        unvisited_neighbors = [(idx, olen) for idx, olen in neighbors if idx not in visited]
        if not unvisited_neighbors:
            break
        next_node = max(unvisited_neighbors, key=lambda x: x[1])[0]
        visited.add(next_node)
        assembly_path.append(next_node)
        current = next_node
    assembled_seq = samples[assembly_path[0]]
    for i in range(1, len(assembly_path)):
        prev = assembly_path[i - 1]
        curr = assembly_path[i]
        olen = get_overlap_len(samples[prev], samples[curr])
        assembled_seq += samples[curr][olen:]
    return assembled_seq

def calc_gc_content(seq):
    g = seq.count('G')
    c = seq.count('C')
    return (g + c) / len(seq) * 100

times = []
gc_contents = []

for accession in accessions:
    seq = get_genome_sequence(accession)
    if seq is None:
        continue
    samples = sample_sequence(seq)
    start_time = time.time()
    assembled_seq = assemble(samples)
    end_time = time.time()
    elapsed_ms = (end_time - start_time) * 1000
    gc = calc_gc_content(seq)
    times.append(elapsed_ms)
    gc_contents.append(gc)
    print(f"Processed {accession}: Time={elapsed_ms:.1f} ms, GC={gc:.2f}%")
    time.sleep(1)

plt.scatter(gc_contents, times)
plt.xlabel('C+G content (%)')
plt.ylabel('Assembly time (ms)')
plt.title('Assembly time vs C+G content for viral genomes')
plt.grid(True)
plt.show()

with open("explanation.txt", "w") as f:
    f.write("This chart plots the time taken to assemble random samples from 10 viral genomes against their C+G percentage.\n")
    f.write("Genomes with higher C+G content tend to have different assembly times possibly due to sequence complexity influencing overlap detection.\n")
    f.write("Assembly time varies with genome size and diversity of sequences affecting overlap graph construction.\n")
    