This files are dedicated for Bioinformatics lab4, to convert codons to amino acid sequences. 23 Oct 2025.

Contributors: Ugur Kaan, Arhir Tudor, Buga Mihai 1242EA.

You can find also find the screenshots of the each outputs. 