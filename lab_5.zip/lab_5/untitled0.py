from Bio import SeqIO
import random

record = SeqIO.read("arbitrary_dna.fasta", "fasta")
original_dna = str(record.seq)

sample_count = 2000
samples = []

for _ in range(sample_count):
    sample_len = random.randint(100, 150)
    start_pos = random.randint(0, len(original_dna) - sample_len)
    samples.append(original_dna[start_pos:start_pos + sample_len])

def get_overlap_len(s1, s2, min_overlap=10):
    max_len = min(len(s1), len(s2))
    for overlap_len in range(max_len, min_overlap - 1, -1):
        if s1[-overlap_len:] == s2[:overlap_len]:
            return overlap_len
    return 0

overlap_graph = {}
for i, s1 in enumerate(samples):
    overlap_graph[i] = []
for i, s1 in enumerate(samples):
    for j, s2 in enumerate(samples):
        if i != j:
            olen = get_overlap_len(s1, s2)
            if olen >= 10:
                overlap_graph[i].append((j, olen))

visited = set()
assembly_path = []
current = 0
visited.add(current)
assembly_path.append(current)

while True:
    neighbors = overlap_graph.get(current, [])
    unvisited_neighbors = [(idx, olen) for idx, olen in neighbors if idx not in visited]
    if not unvisited_neighbors:
        break
    next_node = max(unvisited_neighbors, key=lambda x: x[1])[0]
    visited.add(next_node)
    assembly_path.append(next_node)
    current = next_node

assembled_seq = samples[assembly_path[0]]
for i in range(1, len(assembly_path)):
    prev = assembly_path[i - 1]
    curr = assembly_path[i]
    olen = get_overlap_len(samples[prev], samples[curr])
    assembled_seq += samples[curr][olen:]

print("Length of original DNA:", len(original_dna))
print("Length of assembled DNA:", len(assembled_seq))
print("First 500 bases of assembled DNA:")
print(assembled_seq[:500])

from difflib import SequenceMatcher
similarity = SequenceMatcher(None, original_dna, assembled_seq).ratio()
print(f"Reconstruction similarity to original: {similarity:.4f}")
