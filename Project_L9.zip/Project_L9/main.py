import random
import textwrap

class TransposonSimulator:
    def __init__(self, length=None):
        if length is None:
            self.seq_len = random.randint(200, 400)
        else:
            self.seq_len = length
            
        self.dna = self._generate_random_dna(self.seq_len)
        self.truth_track = [0] * self.seq_len 
        self.te_counter = 0

    def _generate_random_dna(self, length):
        return "".join(random.choice("ATCG") for _ in range(length))

    def insert_transposon(self, sequence, position, tsd_length):
        if position < 0 or position + tsd_length > len(self.dna):
            print(f"[Error] Cannot insert TE at {position}. DNA length is {len(self.dna)}.")
            return False

        self.te_counter += 1
        te_id = self.te_counter

        tsd_seq = self.dna[position : position + tsd_length]
        insertion_block_dna = sequence + tsd_seq
        insertion_block_track = [te_id] * len(sequence) + [0] * tsd_length

        insert_index = position + tsd_length
        
        self.dna = self.dna[:insert_index] + insertion_block_dna + self.dna[insert_index:]
        self.truth_track = self.truth_track[:insert_index] + insertion_block_track + self.truth_track[insert_index:]

        print(f"[Success] Inserted TE #{te_id} (len {len(sequence)}) at index {position}.")
        return True

    def detect_transposons(self, min_te_len, max_te_len, min_tsd, max_tsd):
        detected_coords = []
        n = len(self.dna)

        for tsd_len in range(min_tsd, max_tsd + 1):
            for i in range(n - min_te_len - 2*tsd_len):
                tsd_left = self.dna[i : i + tsd_len]
                
                search_start = i + tsd_len + min_te_len
                search_end = min(n - tsd_len, i + tsd_len + max_te_len)

                for j in range(search_start, search_end + 1):
                    tsd_right = self.dna[j : j + tsd_len]

                    if tsd_left == tsd_right:
                        te_start = i + tsd_len
                        te_end = j 
                        
                        if min_te_len <= (te_end - te_start) <= max_te_len:
                            detected_coords.append((te_start, te_end))
        
        return sorted(list(set(detected_coords)))

    def visualize(self, detected_coords, line_width=80):
        print("\n" + "="*30)
        print(f" VISUALIZATION (Total Length: {len(self.dna)} bp)")
        print("="*30)
        
        true_str = "".join(['-' if x == 0 else str(x) for x in self.truth_track])

        det_str_list = [' '] * len(self.dna)
        for (start, end) in detected_coords:
            for k in range(start, end):
                det_str_list[k] = '#'
        det_str = "".join(det_str_list)

        for i in range(0, len(self.dna), line_width):
            limit = min(i+line_width, len(self.dna))
            print(f"Pos {i}-{limit}")
            print(f"DNA : {self.dna[i:limit]}")
            print(f"TRUE: {true_str[i:limit]}")
            print(f"FIND: {det_str[i:limit]}")
            print("")

if __name__ == "__main__":
    print("--- INITIALIZING SIMULATION ---")
    
    sim = TransposonSimulator() 
    
    print(f"Generated random Host DNA of length: {sim.seq_len} bp")

    te1_seq = "AAACCCGGGTTT" * 3 
    te2_seq = "TGTGTGTG" 

    sim.insert_transposon(te1_seq, position=50, tsd_length=6)
    sim.insert_transposon(te2_seq, position=70, tsd_length=4)

    print("\n--- RUNNING DETECTION ---")
    detected = sim.detect_transposons(
        min_te_len=5,
        max_te_len=100,
        min_tsd=4, 
        max_tsd=8
    )
    
    sim.visualize(detected)